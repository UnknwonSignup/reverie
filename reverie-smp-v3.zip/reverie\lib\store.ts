/**
 * Flat-file JSON store — no database required.
 * All data lives in <project-root>/data/*.json
 * Writes are atomic: write to .tmp then rename.
 */
import 'server-only'
import fs from 'node:fs'
import path from 'node:path'
import { randomUUID } from 'node:crypto'

// ── Types ────────────────────────────────────────────────────────────────────

export type Announcement = {
  id: string
  title: string
  content: string
  author: string
  tag: string
  pinned: boolean
  createdAt: string // ISO
}

export type ForumCategory = {
  id: string
  name: string
  description: string
  position: number
  createdAt: string
}

export type ForumTopic = {
  id: string
  categoryId: string
  title: string
  content: string
  author: string
  pinned: boolean
  locked: boolean
  createdAt: string
}

export type ForumReply = {
  id: string
  topicId: string
  author: string
  content: string
  createdAt: string
}

export type StaffMember = {
  id: string
  username: string
  rank: string
  color: string
  position: number
  online: boolean
  createdAt: string
}

export type AdminUser = {
  id: string
  username: string
  passwordHash: string
  isOwner: boolean
  createdAt: string
}

export type StoreData = {
  announcements: Announcement[]
  categories: ForumCategory[]
  topics: ForumTopic[]
  replies: ForumReply[]
  staff: StaffMember[]
  adminUsers: AdminUser[]
  settings: Record<string, unknown>
}

// ── File paths ────────────────────────────────────────────────────────────────

function dataDir(): string {
  // In production: <cwd>/data  (i.e. the project root/data)
  // In dev: same
  return path.join(process.cwd(), 'data')
}

function filePath(name: string): string {
  return path.join(dataDir(), `${name}.json`)
}

function ensureDir() {
  fs.mkdirSync(dataDir(), { recursive: true })
}

// ── Atomic read/write ─────────────────────────────────────────────────────────

function readJson<T>(name: string, fallback: T): T {
  try {
    const raw = fs.readFileSync(filePath(name), 'utf8')
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

function writeJson<T>(name: string, data: T): void {
  ensureDir()
  const target = filePath(name)
  const tmp = target + '.tmp'
  try {
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8')
    fs.renameSync(tmp, target)
  } catch {
    try {
      fs.writeFileSync(target, JSON.stringify(data, null, 2), 'utf8')
    } catch (e) {
      console.error(`[store] Failed to write ${name}.json:`, e)
    }
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

const now = () => new Date().toISOString()
const uid = () => randomUUID()

// ── Settings ──────────────────────────────────────────────────────────────────

export function readSettings(): Record<string, unknown> {
  return readJson<Record<string, unknown>>('settings', {})
}

export function writeSettings(data: Record<string, unknown>): void {
  writeJson('settings', data)
}

// ── Announcements ─────────────────────────────────────────────────────────────

export function readAnnouncements(): Announcement[] {
  return readJson<Announcement[]>('announcements', [])
}

export function createAnnouncement(fields: Omit<Announcement, 'id' | 'createdAt'>): Announcement {
  const list = readAnnouncements()
  const item: Announcement = { ...fields, id: uid(), createdAt: now() }
  writeJson('announcements', [item, ...list])
  return item
}

export function updateAnnouncement(id: string, patch: Partial<Announcement>): void {
  const list = readAnnouncements().map((a) => (a.id === id ? { ...a, ...patch } : a))
  writeJson('announcements', list)
}

export function deleteAnnouncement(id: string): void {
  writeJson('announcements', readAnnouncements().filter((a) => a.id !== id))
}

// ── Forum categories ──────────────────────────────────────────────────────────

export function readCategories(): ForumCategory[] {
  const cats = readJson<ForumCategory[]>('categories', [])
  if (cats.length > 0) return cats
  const seeds: ForumCategory[] = [
    { id: uid(), name: 'Suggestions', description: 'Share your ideas to improve the server.', position: 1, createdAt: now() },
    { id: uid(), name: 'General Discussion', description: 'Chat about anything and everything.', position: 2, createdAt: now() },
    { id: uid(), name: 'Bug Reports', description: 'Report bugs and issues you encounter in-game.', position: 3, createdAt: now() },
    { id: uid(), name: 'Guides', description: 'Tutorials and tips from the community.', position: 4, createdAt: now() },
    { id: uid(), name: 'Off-Topic', description: "Everything that doesn't fit elsewhere.", position: 5, createdAt: now() },
  ]
  writeJson('categories', seeds)
  return seeds
}

export function readCategoriesWithSeed(): ForumCategory[] {
  return readCategories()
}

export function createCategory(fields: Omit<ForumCategory, 'id' | 'createdAt'>): ForumCategory {
  const list = readCategories()
  const item: ForumCategory = { ...fields, id: uid(), createdAt: now() }
  writeJson('categories', [...list, item])
  return item
}

export function deleteCategory(id: string): void {
  writeJson('categories', readCategories().filter((c) => c.id !== id))
  // cascade
  const topics = readTopics().filter((t) => t.categoryId === id)
  writeJson('topics', readTopics().filter((t) => t.categoryId !== id))
  const topicIds = new Set(topics.map((t) => t.id))
  writeJson('replies', readReplies().filter((r) => !topicIds.has(r.topicId)))
}

// ── Forum topics ──────────────────────────────────────────────────────────────

export function readTopics(): ForumTopic[] {
  return readJson<ForumTopic[]>('topics', [])
}

export function createTopic(fields: Omit<ForumTopic, 'id' | 'createdAt'>): ForumTopic {
  const list = readTopics()
  const item: ForumTopic = { ...fields, id: uid(), createdAt: now() }
  writeJson('topics', [item, ...list])
  return item
}

export function updateTopic(id: string, patch: Partial<ForumTopic>): void {
  writeJson('topics', readTopics().map((t) => (t.id === id ? { ...t, ...patch } : t)))
}

export function deleteTopic(id: string): void {
  writeJson('topics', readTopics().filter((t) => t.id !== id))
  writeJson('replies', readReplies().filter((r) => r.topicId !== id))
}

// ── Forum replies ─────────────────────────────────────────────────────────────

export function readReplies(): ForumReply[] {
  return readJson<ForumReply[]>('replies', [])
}

export function createReply(fields: Omit<ForumReply, 'id' | 'createdAt'>): ForumReply {
  const list = readReplies()
  const item: ForumReply = { ...fields, id: uid(), createdAt: now() }
  writeJson('replies', [...list, item])
  return item
}

export function deleteReply(id: string): void {
  writeJson('replies', readReplies().filter((r) => r.id !== id))
}

// ── Staff ─────────────────────────────────────────────────────────────────────

export function readStaff(): StaffMember[] {
  return readJson<StaffMember[]>('staff', [])
}

export function createStaff(fields: Omit<StaffMember, 'id' | 'createdAt'>): StaffMember {
  const list = readStaff()
  const item: StaffMember = { ...fields, id: uid(), createdAt: now() }
  writeJson('staff', [...list, item])
  return item
}

export function updateStaff(id: string, patch: Partial<StaffMember>): void {
  writeJson('staff', readStaff().map((s) => (s.id === id ? { ...s, ...patch } : s)))
}

export function deleteStaff(id: string): void {
  writeJson('staff', readStaff().filter((s) => s.id !== id))
}

// ── Admin users ───────────────────────────────────────────────────────────────

export function readAdminUsers(): AdminUser[] {
  return readJson<AdminUser[]>('admins', [])
}

export function findAdminUser(username: string): AdminUser | null {
  return readAdminUsers().find((u) => u.username === username) ?? null
}

export function createAdminUser(fields: Omit<AdminUser, 'id' | 'createdAt'>): AdminUser {
  const list = readAdminUsers()
  if (list.find((u) => u.username === fields.username)) throw new Error('Username exists')
  const item: AdminUser = { ...fields, id: uid(), createdAt: now() }
  writeJson('admins', [...list, item])
  return item
}

export function updateAdminUser(id: string, patch: Partial<AdminUser>): void {
  writeJson('admins', readAdminUsers().map((u) => (u.id === id ? { ...u, ...patch } : u)))
}

export function deleteAdminUser(id: string): void {
  writeJson('admins', readAdminUsers().filter((u) => u.id !== id))
}

// ── Rate-limit helpers (in-memory, resets on restart — fine for VPS) ──────────

const recentReplies = new Map<string, number>()

export function canReply(author: string, cooldownMs = 30_000): boolean {
  const last = recentReplies.get(author.toLowerCase())
  if (last && Date.now() - last < cooldownMs) return false
  recentReplies.set(author.toLowerCase(), Date.now())
  return true
}

const recentTopics = new Map<string, number>()

export function canPost(author: string, cooldownMs = 120_000): boolean {
  const last = recentTopics.get(author.toLowerCase())
  if (last && Date.now() - last < cooldownMs) return false
  recentTopics.set(author.toLowerCase(), Date.now())
  return true
}

// ── Tickets ───────────────────────────────────────────────────────────────────

export type TicketStatus = 'open' | 'in-progress' | 'closed'

export type Ticket = {
  id: string
  title: string
  reason: string
  minecraftUser: string
  discordUser: string
  discordUserId?: string
  content: string
  status: TicketStatus
  createdAt: string
}

export function readTickets(): Ticket[] {
  return readJson<Ticket[]>('tickets', [])
}

export function createTicket(fields: Omit<Ticket, 'id' | 'createdAt' | 'status'> & { discordUserId?: string }): Ticket {
  const list = readTickets()
  const item: Ticket = { ...fields, id: uid(), status: 'open', createdAt: now() }
  writeJson('tickets', [item, ...list])
  return item
}

export function updateTicketStatus(id: string, status: TicketStatus): void {
  writeJson('tickets', readTickets().map((t) => (t.id === id ? { ...t, status } : t)))
}

export function deleteTicket(id: string): void {
  writeJson('tickets', readTickets().filter((t) => t.id !== id))
}

const recentTickets = new Map<string, number>()

export function canSubmitTicket(discordUser: string, cooldownMs = 300_000): boolean {
  const key = discordUser.toLowerCase()
  const last = recentTickets.get(key)
  if (last && Date.now() - last < cooldownMs) return false
  recentTickets.set(key, Date.now())
  return true
}

// ── Ticket Messages ────────────────────────────────────────────────────────────

export type TicketMessage = {
  id: string
  ticketId: string
  authorId: string
  authorName: string
  content: string
  createdAt: string
  isStaff: boolean
}

export function readTicketMessages(ticketId: string): TicketMessage[] {
  return readJson<TicketMessage[]>('ticket-messages', []).filter((m) => m.ticketId === ticketId)
}

export function createTicketMessage(fields: Omit<TicketMessage, 'id' | 'createdAt'>): TicketMessage {
  const all = readJson<TicketMessage[]>('ticket-messages', [])
  const item: TicketMessage = { ...fields, id: uid(), createdAt: now() }
  writeJson('ticket-messages', [...all, item])
  return item
}

export function deleteTicketMessage(id: string): void {
  const all = readJson<TicketMessage[]>('ticket-messages', [])
  writeJson('ticket-messages', all.filter((m) => m.id !== id))
}
