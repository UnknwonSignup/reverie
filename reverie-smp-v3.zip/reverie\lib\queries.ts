import 'server-only'
import {
  readAnnouncements,
  readCategories,
  readTopics,
  readReplies,
  readStaff,
  readAdminUsers,
  readTickets,
  readTicketMessages,
  type Announcement,
  type ForumCategory,
  type ForumTopic,
  type ForumReply,
  type StaffMember,
  type AdminUser,
  type Ticket,
  type TicketStatus,
  type TicketMessage,
} from './store'

// Re-export types so existing imports keep working
export type { Announcement, ForumCategory, ForumTopic, ForumReply, StaffMember, AdminUser, Ticket, TicketStatus, TicketMessage }

export function getAnnouncements(limit = 20): Announcement[] {
  return readAnnouncements()
    .sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1
      return b.createdAt.localeCompare(a.createdAt)
    })
    .slice(0, limit)
}

export function getStaff(): StaffMember[] {
  return readStaff().sort((a, b) => (a.position ?? 0) - (b.position ?? 0) || (a.createdAt ?? '').localeCompare(b.createdAt ?? ''))
}

export function getForumOverview() {
  const categories = readCategories().sort((a, b) => (a.position ?? 0) - (b.position ?? 0) || (a.createdAt ?? '').localeCompare(b.createdAt ?? ''))
  const topics = readTopics()
  const replies = readReplies()
  return categories.map((cat) => {
    const catTopics = topics.filter((t) => t.categoryId === cat.id)
    const latest = catTopics.sort((a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? ''))[0] ?? null
    const replyCount = catTopics.reduce((acc, t) => acc + replies.filter((r) => r.topicId === t.id).length, 0)
    return { ...cat, topicCount: catTopics.length, replyCount, latestTopic: latest }
  })
}

export function getCategoryWithTopics(categoryId: string) {
  const category = readCategories().find((c) => c.id === categoryId)
  if (!category) return null
  const replies = readReplies()
  const topics = readTopics()
    .filter((t) => t.categoryId === categoryId)
    .sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1
      return (b.createdAt ?? '').localeCompare(a.createdAt ?? '')
    })
    .map((t) => {
      const replyCount = replies.filter((r) => r.topicId === t.id).length
      return { ...t, replyCount, isHot: replyCount > 5 }
    })
  return { category, topics }
}

export function getTopicWithReplies(topicId: string) {
  const topic = readTopics().find((t) => t.id === topicId)
  if (!topic) return null
  const category = readCategories().find((c) => c.id === topic.categoryId) ?? null
  const replies = readReplies()
    .filter((r) => r.topicId === topicId)
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
  return { topic, category, replies }
}

export function getAdminData() {
  const announcements = getAnnouncements(100)
  const categories = readCategories().sort((a, b) => a.position - b.position)
  const topics = readTopics().sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  const staff = getStaff()
  const replies = readReplies().sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 50)
  const adminUsers = readAdminUsers().map(({ passwordHash: _, ...rest }) => rest)
  const tickets = readTickets()
  return { announcements, categories, topics, staff, replies, adminUsers, tickets }
}

export { readTickets, readTicketMessages } from './store'
